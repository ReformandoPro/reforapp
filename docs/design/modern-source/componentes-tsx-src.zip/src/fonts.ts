import { Inter, Space_Grotesk } from "next/font/google";

/**
 * Fuentes del sistema, auto-hospedadas por Next (sin llamada externa, sin parpadeo).
 *
 * Variables CSS que Tailwind consume:
 *   --font-inter         -> font-sans  (toda la interfaz)
 *   --font-space-grotesk -> font-num   (solo cifras grandes: importes, %, m²)
 *
 * Uso en app/layout.tsx:
 *   import { fontVariables } from "@/ui/fonts";
 *   <html lang="es" className={fontVariables}> ...
 */
export const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
  weight: ["400", "500", "600", "700"],
});

export const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-space-grotesk",
  weight: ["500", "600", "700"],
});

/** Cadena lista para el className del <html> (o <body>). */
export const fontVariables = `${inter.variable} ${spaceGrotesk.variable}`;
