# Componentes TSX — Sistema de Diseño

Carpeta `src/` lista para soltar en vuestro repo Next.js (App Router). Solo componentes de presentación; sin andamiaje, sin configs, sin ejemplos.

> Validado con `tsc --noEmit` en **strict mode**: 0 errores (validado de forma aislada, sin el resto del proyecto).

## Contenido

```
src/
├── index.ts        # barrel: import { Button } from "@/ui"; import type { ButtonProps } ...
├── cn.ts           # helper de clases (tipado, sin dependencias)
├── types.ts        # tipos del sistema (SemanticStatus, ButtonVariant, TimelineItem, ...)
├── fonts.ts        # next/font (Inter + Space Grotesk)
└── components/      # 15 componentes .tsx
    ├── Avatar.tsx
    ├── Badge.tsx
    ├── Button.tsx
    ├── Card.tsx
    ├── Checkbox.tsx
    ├── Donut.tsx
    ├── EmptyState.tsx
    ├── GuildChip.tsx
    ├── Input.tsx
    ├── ListItem.tsx      (incluye ListGroup)
    ├── MetricCard.tsx    (incluye MetricCardGroup)
    ├── ProgressBar.tsx
    ├── SegmentedControl.tsx
    ├── TabBar.tsx
    └── Timeline.tsx
```

## Cumple

- **`.tsx` con props tipadas** (interfaces exportadas por componente).
- **Sin lógica de negocio** — solo render + callbacks de UI.
- **Sin Supabase / Auth / API / data fetching.**
- **Sin dependencias nuevas** — solo `react` / `next`. El helper `cn` es propio; los iconos se pasan como `ReactNode`.
- **Tailwind** — clases de vuestra config (estilos inline solo en dimensiones de SVG y `width` de barras).
- **App Router** — `"use client"` solo en interactivos; el resto, Server Components.

## Requisitos para que compile/renderice en vuestro repo

Este paquete asume dos cosas que **ya tenéis** (o que vienen en el paquete del sistema de diseño):

1. **Config de Tailwind del sistema** — define `primary`, `success`, `warning`, `danger`, `guild`, `bg`, `content`, radios, `font-sans`/`font-num`, `shadow-fab`, `ring-focus`. Sin esos tokens, las clases no resuelven. (Está en `tailwind.config.ts` del paquete del sistema.)
2. **Fuentes cargadas** — `fonts.ts` usa `next/font`; importad `fontVariables` en vuestro `layout.tsx` y aplicad la clase `dark` al `<html>`.

> Si en vuestro `tsconfig` permitís imports de `*.css` como efecto lateral en algún sitio y os hace falta, añadid `declare module "*.css";` en un `.d.ts`. Aquí no se incluye porque este paquete no importa CSS.

## Server / Client

- `"use client"`: `Button`, `Input`, `Checkbox`, `SegmentedControl`, `TabBar`, `ListItem`, `MetricCard`.
- Server Components: `Card`, `Badge`, `GuildChip`, `ProgressBar`, `Donut`, `Timeline`, `Avatar`, `EmptyState`.

La directiva va en cada archivo, **no** en `index.ts`.

## Reglas del sistema que el código hace cumplir

1. **Estado ≠ gremio** — `Badge` (`status: SemanticStatus`) y `GuildChip` (sin prop de color) separados.
2. **Verde = dinero y validación** — `Button variant="confirm"`, `Timeline status="done"`. Progreso y selección son azules.
3. **Escalas ordenadas** — `SegmentedControl`: de menor a mayor (Aprendiz → Oficial 2ª → Oficial 1ª).
4. **EmptyState neutro** — el estado vacío no usa color semántico (no es éxito ni error).

## Uso

```tsx
import { Button, EmptyState } from "@/ui";

<EmptyState
  title="Aún no hay partidas"
  description="Añade la primera partida para empezar el presupuesto."
  action={<Button variant="primary">Añadir Partida</Button>}
/>
```

Todos aceptan `className` (se concatena al final) para ajustes puntuales.
