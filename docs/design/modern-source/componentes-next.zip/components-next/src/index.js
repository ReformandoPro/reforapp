/**
 * Sistema de Diseño — Librería de componentes
 * Punto de entrada único. Importa así:
 *
 *   import { Button, Card, Badge, GuildChip } from "@/components";
 */

export { cn } from "./cn";

export { Button } from "./components/Button";
export { Card } from "./components/Card";
export { Badge } from "./components/Badge";
export { GuildChip } from "./components/GuildChip";
export { Input } from "./components/Input";
export { Checkbox } from "./components/Checkbox";
export { ProgressBar } from "./components/ProgressBar";
export { Donut } from "./components/Donut";
export { Timeline } from "./components/Timeline";
export { Avatar } from "./components/Avatar";
export { SegmentedControl } from "./components/SegmentedControl";
export { TabBar } from "./components/TabBar";
export { ListItem, ListGroup } from "./components/ListItem";
export { MetricCard, MetricCardGroup } from "./components/MetricCard";
