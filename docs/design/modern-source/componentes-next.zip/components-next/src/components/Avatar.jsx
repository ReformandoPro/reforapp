import { cn } from "../cn";

/**
 * Avatar — imagen de perfil circular del sistema.
 *
 * Props:
 *  - src      : URL de imagen. Si no hay, muestra iniciales o icono de persona.
 *  - initials : iniciales de respaldo (p. ej. "JM").
 *  - size     : sm (40) | md (54) | lg (108).
 *  - ring     : muestra el anillo azul (border-primary-700).
 *  - verified : muestra el badge azul de verificación abajo a la derecha.
 *  - alt      : texto alternativo.
 */
export function Avatar({
  src,
  initials,
  size = "md",
  ring = false,
  verified = false,
  alt = "",
  className = "",
}) {
  const px = { sm: 40, md: 54, lg: 108 }[size];
  const verifyPx = size === "lg" ? 30 : size === "md" ? 22 : 18;

  return (
    <div className={cn("relative inline-block", className)} style={{ width: px, height: px }}>
      <div
        className={cn(
          "w-full h-full rounded-full overflow-hidden flex items-center justify-center",
          "bg-gradient-to-br from-[#46566b] to-[#222d3a]",
          ring && "border-[3px] border-primary-700"
        )}
      >
        {src ? (
          <img src={src} alt={alt} className="w-full h-full object-cover" />
        ) : initials ? (
          <span className="font-semibold text-content-primary" style={{ fontSize: px * 0.34 }}>
            {initials}
          </span>
        ) : (
          <svg viewBox="0 0 24 24" fill="#c7d2e0" style={{ width: px * 0.54, height: px * 0.54 }}>
            <path d="M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-4 0-8 2-8 5v1h16v-1c0-3-4-5-8-5z" />
          </svg>
        )}
      </div>

      {verified && (
        <span
          className="absolute bottom-0.5 right-0.5 rounded-full bg-primary-500 border-[3px] border-bg-base flex items-center justify-center"
          style={{ width: verifyPx, height: verifyPx }}
          aria-label="Verificado"
        >
          <svg width={verifyPx * 0.5} height={verifyPx * 0.5} viewBox="0 0 24 24" fill="none"
               stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6L9 17l-5-5" />
          </svg>
        </span>
      )}
    </div>
  );
}
