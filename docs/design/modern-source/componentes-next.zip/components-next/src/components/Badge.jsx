import { cn } from "../cn";

/**
 * Badge — etiqueta de ESTADO semántico.
 *
 * IMPORTANTE: Badge es solo para estados. Para gremios/especialidades usa <GuildChip>.
 * Esta separación es deliberada: evita reintroducir el "exceso de color" que el
 * sistema corrige (un color de estado nunca debe usarse como categoría).
 *
 * Estados:
 *  - info    : azul   → "EN PROGRESO", "ACTUAL", "FASE 3 DE 5"
 *  - success : verde  → "ENTREGADO", "FINALIZADO", "AL DÍA", "PAGADO"
 *  - warning : ámbar  → "BORRADOR", "PENDIENTE", "MATERIAL PENDIENTE"
 *  - danger  : rojo   → solo errores
 *  - neutral : gris   → contadores neutros ("3 Partidas")
 *
 * Props:
 *  - dot   : muestra un punto de color delante del texto.
 *  - pill  : esquinas de cápsula (por defecto rounded-sm).
 */
export function Badge({
  status = "info",
  dot = false,
  pill = false,
  className = "",
  children,
  ...props
}) {
  const variants = {
    info: "bg-primary-900 text-primary-100",
    success: "bg-success-900 text-success-100",
    warning: "bg-warning-900 text-warning-100",
    danger: "bg-danger-900 text-danger-100",
    neutral: "bg-bg-raised text-content-secondary border border-subtle",
  };

  const dotColors = {
    info: "bg-primary-300",
    success: "bg-success-300",
    warning: "bg-warning-500",
    danger: "bg-danger-500",
    neutral: "bg-content-tertiary",
  };

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-overline font-semibold uppercase tracking-wide px-3 py-1",
        pill ? "rounded-full" : "rounded-sm",
        variants[status],
        className
      )}
      {...props}
    >
      {dot && <span className={cn("w-2 h-2 rounded-full", dotColors[status])} />}
      {children}
    </span>
  );
}
