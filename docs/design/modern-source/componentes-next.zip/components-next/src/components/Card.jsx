import { cn } from "../cn";

/**
 * Card — contenedor de superficie del sistema.
 *
 * Variantes:
 *  - surface : tarjeta estándar (bg-surface).
 *  - raised  : tarjeta elevada / seleccionada (bg-raised).
 *  - active  : tarjeta destacada (fondo azul primario, texto blanco). Máx. una por grupo.
 *  - dashed  : zona de acción "añadir" (borde punteado).
 *
 * Props:
 *  - padding : sm | md | lg (por defecto md = p-5).
 *  - as      : etiqueta a renderizar (div por defecto). Útil para <button> o <section>.
 */
export function Card({
  variant = "surface",
  padding = "md",
  as: Tag = "div",
  className = "",
  children,
  ...props
}) {
  const paddings = { sm: "p-4", md: "p-5", lg: "p-6" };

  const variants = {
    surface: "bg-bg-surface border border-subtle",
    raised: "bg-bg-raised border border-default",
    active: "bg-primary-500 text-white border border-primary-500",
    dashed: "bg-transparent border border-dashed border-strong",
  };

  return (
    <Tag
      className={cn("rounded-lg", paddings[padding], variants[variant], className)}
      {...props}
    >
      {children}
    </Tag>
  );
}
