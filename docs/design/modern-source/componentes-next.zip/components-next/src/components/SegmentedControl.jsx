"use client";

import { cn } from "../cn";

/**
 * SegmentedControl — selector de una opción entre varias (p. ej. nivel de experiencia).
 *
 * La opción activa usa superficie elevada (bg-raised) en lugar de un color fuerte,
 * para no competir con los acentos del sistema.
 *
 * NOTA DE ORDEN: cuando las opciones representan una escala (niveles, tallas, rangos),
 * ordénalas siempre de menor a mayor de izquierda a derecha.
 * Ej. ["Aprendiz", "Oficial 2ª", "Oficial 1ª"], no al revés.
 *
 * Props:
 *  - options : array de strings, o de { value, label }.
 *  - value   : valor seleccionado.
 *  - onChange: recibe el value elegido.
 */
export function SegmentedControl({ options = [], value, onChange, className = "" }) {
  const normalized = options.map((o) =>
    typeof o === "string" ? { value: o, label: o } : o
  );

  return (
    <div
      role="radiogroup"
      className={cn(
        "grid gap-2 bg-bg-surface border border-subtle rounded-[14px] p-1.5",
        className
      )}
      style={{ gridTemplateColumns: `repeat(${normalized.length}, minmax(0, 1fr))` }}
    >
      {normalized.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => onChange?.(opt.value)}
            className={cn(
              "py-2.5 px-2 rounded-[9px] text-label font-semibold text-center transition-colors duration-150 border",
              active
                ? "bg-bg-raised text-content-primary border-default"
                : "bg-transparent text-content-tertiary border-transparent hover:text-content-secondary"
            )}
          >
            {opt.label}
          </button>
        );
      })}
    </div>
  );
}
