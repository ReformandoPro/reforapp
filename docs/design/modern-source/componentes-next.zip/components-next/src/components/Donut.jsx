import { cn } from "../cn";

/**
 * Donut — gráfico circular (donut) del sistema.
 *
 * Para series sin significado semántico, usa una escala MONOCROMA de azules en vez
 * de colores arbitrarios (así dos series se distinguen sin introducir colores nuevos).
 * La paleta por defecto va de azul fuerte a azul claro.
 *
 * Props:
 *  - segments : array de { value, color?, label? }. Si no se da color, se asigna
 *               automáticamente desde la escala de azules.
 *  - size     : diámetro en px (def. 118).
 *  - thickness: grosor del anillo en px (def. 11).
 *  - centerLabel : nodo o texto en el centro (p. ej. "24%" o un icono).
 *  - showLegend  : muestra la leyenda con los labels de cada segmento.
 *  - track    : color de la pista de fondo.
 */
const BLUE_SCALE = ["#2D7FF9", "#6FA8F6", "#C7DEFD", "#1850AB"];

export function Donut({
  segments = [],
  size = 118,
  thickness = 11,
  centerLabel = null,
  showLegend = false,
  track = "rgba(255,255,255,0.07)",
  className = "",
}) {
  const radius = (size - thickness) / 2;
  const circumference = 2 * Math.PI * radius;
  const total = segments.reduce((s, seg) => s + seg.value, 0) || 1;

  let offsetAcc = 0;
  const arcs = segments.map((seg, i) => {
    const len = (seg.value / total) * circumference;
    const color = seg.color || BLUE_SCALE[i % BLUE_SCALE.length];
    const arc = {
      color,
      dasharray: `${len} ${circumference - len}`,
      dashoffset: -offsetAcc,
      label: seg.label,
    };
    offsetAcc += len;
    return arc;
  });

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: "rotate(-90deg)" }}>
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={track} strokeWidth={thickness} />
          {arcs.map((arc, i) => (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={arc.color}
              strokeWidth={thickness}
              strokeLinecap="round"
              strokeDasharray={arc.dasharray}
              strokeDashoffset={arc.dashoffset}
            />
          ))}
        </svg>
        {centerLabel != null && (
          <div className="absolute inset-0 flex items-center justify-center">
            {typeof centerLabel === "string" ? (
              <span className="font-num text-2xl font-bold text-content-primary">{centerLabel}</span>
            ) : (
              centerLabel
            )}
          </div>
        )}
      </div>

      {showLegend && (
        <div className="flex gap-3.5 mt-3.5">
          {arcs.map((arc, i) =>
            arc.label ? (
              <span key={i} className="flex items-center gap-1.5 text-caption text-content-secondary font-medium">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: arc.color }} />
                {arc.label}
              </span>
            ) : null
          )}
        </div>
      )}
    </div>
  );
}
