"use client";

import { cn } from "../cn";

/**
 * MetricCard — tarjeta de métrica/KPI (p. ej. "ACTIVOS 12" en el dashboard).
 *
 * La tarjeta activa usa fondo azul primario con texto blanco. Regla: como máximo
 * UNA tarjeta activa por grupo (es el acento que guía la vista).
 *
 * Props:
 *  - label  : etiqueta superior (overline).
 *  - value  : cifra principal (se renderiza en Space Grotesk).
 *  - footer : nodo opcional debajo (p. ej. un Badge de tendencia "+2" o "Pend.").
 *  - active : versión azul destacada.
 */
export function MetricCard({ label, value, footer = null, active = false, className = "" }) {
  return (
    <div
      className={cn(
        "rounded-lg p-5 min-w-0",
        active
          ? "bg-primary-500 text-white"
          : "bg-bg-surface border border-subtle text-content-primary",
        className
      )}
    >
      <p
        className={cn(
          "text-overline font-semibold uppercase tracking-wide mb-2",
          active ? "text-white/80" : "text-content-secondary"
        )}
      >
        {label}
      </p>
      <p className="font-num text-[34px] font-bold leading-none mb-3">{value}</p>
      {footer}
    </div>
  );
}

/**
 * MetricCardGroup — fila horizontal de MetricCards con scroll lateral en móvil,
 * tal como aparecen en el dashboard ("ACTIVOS / PRESUPUESTOS / COMPRAS").
 */
export function MetricCardGroup({ className = "", children }) {
  return (
    <div className={cn("flex gap-3 overflow-x-auto pb-1 -mx-1 px-1 snap-x", className)}>
      {/* Cada hijo recibe un ancho mínimo cómodo y se alinea al hacer snap */}
      {Array.isArray(children)
        ? children.map((child, i) => (
            <div key={i} className="snap-start shrink-0 w-[44%] min-w-[150px]">
              {child}
            </div>
          ))
        : children}
    </div>
  );
}
