import { cn } from "../cn";

/**
 * GuildChip — etiqueta de GREMIO / especialidad (Albañilería, Fontanería, Pintura…).
 *
 * Todos los gremios comparten EXACTAMENTE el mismo aspecto neutro y se diferencian
 * solo por el texto. Esto es una decisión central del sistema: con 8+ gremios,
 * asignar un color a cada uno produce un arcoíris que compite con los estados
 * semánticos (verde y rojo ya tienen significado fijo).
 *
 * Por eso este componente NO acepta una prop de color. Si en el futuro se necesita
 * distinguir gremios de un vistazo, el camino correcto es un icono por gremio
 * (monocromo), que puede pasarse en `icon`.
 *
 * Props:
 *  - icon : nodo opcional (icono monocromo del gremio).
 *  - pill : esquinas de cápsula (por defecto rounded-sm).
 */
export function GuildChip({ icon = null, pill = false, className = "", children, ...props }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 text-overline font-semibold uppercase tracking-wide px-2.5 py-1",
        "bg-guild-bg text-guild-text border border-guild-border",
        pill ? "rounded-full" : "rounded-sm",
        className
      )}
      {...props}
    >
      {icon}
      {children}
    </span>
  );
}
