import { cn } from "../cn";

/**
 * ProgressBar — barra de progreso del sistema.
 *
 * Por defecto el relleno es AZUL (color de dato/progreso). Solo cuando el contexto
 * es un aviso real (p. ej. proyecto con material pendiente) se usa tone="warning".
 * No usar verde aquí: el verde es para dinero y completado, no para "progreso".
 *
 * Props:
 *  - value : 0–100.
 *  - tone  : "primary" (def.) | "warning".
 *  - height: sm (6px) | md (8px) | lg (9px).
 */
export function ProgressBar({ value = 0, tone = "primary", height = "md", className = "", ...props }) {
  const clamped = Math.max(0, Math.min(100, value));
  const heights = { sm: "h-1.5", md: "h-2", lg: "h-[9px]" };
  const tones = { primary: "bg-primary-500", warning: "bg-warning-500" };

  return (
    <div
      className={cn("w-full rounded-full overflow-hidden bg-white/[0.07]", heights[height], className)}
      role="progressbar"
      aria-valuenow={clamped}
      aria-valuemin={0}
      aria-valuemax={100}
      {...props}
    >
      <div
        className={cn("h-full rounded-full transition-[width] duration-500", tones[tone])}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}
