"use client";

import { cn } from "../cn";

/**
 * Checkbox — casilla circular del sistema (estilo "marcar como hecho").
 *
 * Usa AZUL al marcar, no verde: marcar un item es una acción de selección/progreso,
 * territorio del azul. El verde queda reservado a dinero y a validaciones/hitos reales.
 *
 * Props:
 *  - checked  : estado controlado.
 *  - onChange : recibe el nuevo booleano.
 *  - size     : sm (22px) | md (26px).
 *  - label    : texto opcional a la derecha (no se tacha automáticamente; eso lo
 *               decide el componente de lista, p. ej. ListItem).
 *  - disabled : desactiva la interacción.
 */
export function Checkbox({
  checked = false,
  onChange,
  size = "md",
  label,
  disabled = false,
  className = "",
  ...props
}) {
  const sizes = { sm: "w-[22px] h-[22px]", md: "w-[26px] h-[26px]" };
  const checkSize = size === "sm" ? 12 : 14;

  return (
    <label
      className={cn(
        "inline-flex items-center gap-3",
        disabled ? "opacity-50 pointer-events-none" : "cursor-pointer",
        className
      )}
    >
      <button
        type="button"
        role="checkbox"
        aria-checked={checked}
        disabled={disabled}
        onClick={() => onChange?.(!checked)}
        className={cn(
          "flex items-center justify-center rounded-full border-2 transition-colors duration-150 shrink-0",
          sizes[size],
          checked
            ? "bg-primary-500 border-primary-500"
            : "bg-transparent border-strong hover:border-primary-500"
        )}
        {...props}
      >
        {checked && (
          <svg width={checkSize} height={checkSize} viewBox="0 0 24 24" fill="none"
               stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6L9 17l-5-5" />
          </svg>
        )}
      </button>
      {label && <span className="text-[15px] text-content-primary">{label}</span>}
    </label>
  );
}
