"use client";

import { cn } from "../cn";

/**
 * Button — botón del sistema de diseño.
 *
 * Variantes:
 *  - primary    : acción principal (azul). Es el CTA por defecto.
 *  - confirm    : confirmación / dinero (verde). Solo para cobrar, confirmar pago, finalizar obra.
 *  - secondary  : acción alternativa (superficie elevada).
 *  - text       : enlace de acción (sin fondo).
 *  - destructive: eliminar (rojo, solo icono+texto).
 *
 * Tamaños: sm | md | lg
 *
 * Props extra:
 *  - fullWidth  : ocupa el 100% del ancho.
 *  - iconLeft / iconRight: nodos (p. ej. un <svg/> o un icono de lucide-react).
 *  - elevated   : añade la sombra azul de elevación (para CTAs flotantes).
 */
export function Button({
  variant = "primary",
  size = "md",
  fullWidth = false,
  elevated = false,
  iconLeft = null,
  iconRight = null,
  className = "",
  children,
  ...props
}) {
  const base =
    "inline-flex items-center justify-center gap-2 font-semibold rounded-md " +
    "transition-colors duration-150 focus:outline-none focus-visible:ring-2 " +
    "focus-visible:ring-focus disabled:opacity-50 disabled:pointer-events-none select-none";

  const sizes = {
    sm: "text-label px-4 py-2",
    md: "text-[15px] px-5 py-3",
    lg: "text-[15px] px-5 py-4",
  };

  const variants = {
    primary: "bg-primary-500 text-white hover:bg-primary-600",
    confirm: "bg-success-500 text-white hover:bg-success-700",
    secondary:
      "bg-bg-raised text-content-primary border border-default hover:border-strong",
    text: "bg-transparent text-primary-300 hover:text-primary-100 px-2 py-1",
    destructive:
      "bg-transparent text-danger-500 hover:bg-danger-900/40",
  };

  return (
    <button
      className={cn(
        base,
        sizes[size],
        variants[variant],
        fullWidth && "w-full",
        elevated && "shadow-fab",
        className
      )}
      {...props}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
