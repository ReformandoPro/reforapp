"use client";

import { cn } from "../cn";
import { Checkbox } from "./Checkbox";

/**
 * ListItem — fila de lista densa (p. ej. material en la lista de compra).
 *
 * Cuando `done` es true, el texto se tacha y atenúa. El check usa azul (acción de
 * selección/progreso), coherente con Checkbox.
 *
 * Para agrupar varios ListItem dentro de una misma tarjeta, envuélvelos en
 * <ListGroup> (abajo), que añade los separadores entre filas.
 *
 * Props:
 *  - title   : nombre principal.
 *  - subtitle: línea secundaria (p. ej. "Cantidad: 25 sacos").
 *  - done     : estado comprado/hecho.
 *  - onToggle : recibe el nuevo booleano.
 *  - trailing : nodo a la derecha (p. ej. un precio o un chevron). Si no se da y hay
 *               onToggle, no se muestra nada a la derecha.
 *  - showCheck: muestra el checkbox a la izquierda (def. true).
 */
export function ListItem({
  title,
  subtitle,
  done = false,
  onToggle,
  trailing = null,
  showCheck = true,
  className = "",
}) {
  return (
    <div className={cn("flex items-center gap-3.5 px-4 py-3.5", className)}>
      {showCheck && <Checkbox checked={done} onChange={onToggle} />}

      <div className="flex-1 min-w-0">
        <p
          className={cn(
            "text-[15px] font-semibold mb-0.5 truncate",
            done ? "text-content-tertiary line-through" : "text-content-primary"
          )}
        >
          {title}
        </p>
        {subtitle && (
          <p className={cn("text-caption truncate", done ? "text-content-disabled" : "text-content-tertiary")}>
            {subtitle}
          </p>
        )}
      </div>

      {trailing && <div className="shrink-0">{trailing}</div>}
    </div>
  );
}

/**
 * ListGroup — agrupa ListItems en una tarjeta con separadores entre filas.
 */
export function ListGroup({ className = "", children }) {
  return (
    <div
      className={cn(
        "bg-bg-surface border border-subtle rounded-[14px] overflow-hidden",
        "divide-y divide-white/[0.06]",
        className
      )}
    >
      {children}
    </div>
  );
}
