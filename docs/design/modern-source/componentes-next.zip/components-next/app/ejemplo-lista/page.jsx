import { Button } from "@/ui";
import { ShoppingList } from "./ShoppingList";

/**
 * Página de ejemplo: Lista de Compra.
 *
 * Esto es un SERVER COMPONENT (no lleva "use client"): puede hacer fetch de datos,
 * leer de la base de datos, etc. La interactividad vive en <ShoppingList>, que es
 * la isla cliente. Aquí los datos van hardcodeados como demo; en real vendrían de
 * tu capa de datos.
 */
const DEMO_GROUPS = [
  {
    guild: "Albañilería",
    items: [
      { name: "Sacos de Cemento Portland", qty: "Cantidad: 25 sacos", done: false },
      { name: "Ladrillo Cerámico Hueco", qty: "Cantidad: 400 unidades", done: false },
    ],
  },
  {
    guild: "Fontanería",
    items: [{ name: "Tubería Cobre 15mm", qty: "Cantidad: 24 metros", done: true }],
  },
  {
    guild: "Calefacción", // neutro: ya no en rojo
    items: [{ name: "Radiador Aluminio 10 elem.", qty: "Cantidad: 4 unidades", done: false }],
  },
  {
    guild: "Pintura",
    items: [{ name: "Pintura Plástica Blanca 15L", qty: "Cantidad: 4 botes", done: false }],
  },
];

export default function ListaCompraPage() {
  return (
    <main className="max-w-md mx-auto px-5 pt-6 pb-10">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-h2">Lista de Compra</h1>
        <Button variant="text">Finalizar</Button>
      </header>

      <ShoppingList initialGroups={DEMO_GROUPS} />

      <div className="mt-8">
        <Button variant="primary" fullWidth elevated>
          Generar Orden de Compra
        </Button>
      </div>
    </main>
  );
}
