"use client";

import { useState } from "react";
import { ListGroup, ListItem, GuildChip, ProgressBar } from "@/ui";

/**
 * ShoppingList — parte INTERACTIVA de la pantalla de lista de compra.
 *
 * Patrón App Router: esta isla cliente contiene el estado (qué items están
 * comprados); la página que la usa puede seguir siendo Server Component.
 *
 * Recibe los datos ya cargados (p. ej. desde el servidor) por props.
 */
export function ShoppingList({ initialGroups }) {
  const [groups, setGroups] = useState(initialGroups);

  const toggle = (groupIdx, itemIdx) => {
    setGroups((prev) =>
      prev.map((g, gi) =>
        gi !== groupIdx
          ? g
          : { ...g, items: g.items.map((it, ii) => (ii !== itemIdx ? it : { ...it, done: !it.done })) }
      )
    );
  };

  const allItems = groups.flatMap((g) => g.items);
  const bought = allItems.filter((i) => i.done).length;
  const pct = allItems.length ? Math.round((bought / allItems.length) * 100) : 0;

  return (
    <div>
      {groups.map((group, gi) => (
        <section key={group.guild} className="mb-6">
          <div className="flex items-center justify-between mb-3 px-1">
            <GuildChip>{group.guild}</GuildChip>
            <span className="text-overline font-semibold uppercase tracking-wide text-content-tertiary">
              {group.items.length} {group.items.length === 1 ? "Material" : "Materiales"}
            </span>
          </div>
          <ListGroup>
            {group.items.map((item, ii) => (
              <ListItem
                key={item.name}
                title={item.name}
                subtitle={item.qty}
                done={item.done}
                onToggle={() => toggle(gi, ii)}
              />
            ))}
          </ListGroup>
        </section>
      ))}

      <div className="mt-8 flex items-center gap-3">
        <ProgressBar value={pct} className="flex-1" />
        <span className="font-num text-caption font-semibold text-primary-300">{pct}%</span>
      </div>
      <p className="mt-1 text-caption text-content-tertiary text-right">
        {bought} de {allItems.length} comprados
      </p>
    </div>
  );
}
