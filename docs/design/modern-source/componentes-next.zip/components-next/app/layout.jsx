import "./globals.css";
import { fontVariables } from "@/ui/fonts";

export const metadata = {
  title: "Gestión de Reformas",
  description: "App de gestión de reformas y obras",
};

/**
 * Root layout (App Router).
 *
 * - `fontVariables` inyecta --font-inter y --font-space-grotesk en el <html>,
 *   que Tailwind consume vía font-sans / font-num.
 * - La clase `dark` activa el tema oscuro (el sistema es dark por defecto).
 * - El <body> fija el fondo base y el color de texto del sistema.
 *
 * Ajusta el import "@/ui/..." a donde coloques la carpeta src/ (alias en jsconfig).
 */
export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${fontVariables} dark`}>
      <body className="bg-bg-base text-content-primary font-sans antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
